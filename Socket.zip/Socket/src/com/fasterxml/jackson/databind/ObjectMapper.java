package com.fasterxml.jackson.databind;

public interface ObjectMapper {

}
